package com.example.thisispomodoro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    public static int seekbar1 = 25;   //колво минут работы
    public int seekbar2 = 5;  //колво минут перерыва
    public int seekbar3 = 15; //колво минут долгого отдыха


    private SeekBar sb1;
    private SeekBar sb2;
    private SeekBar sb3;
    private TextView tv1;
    private TextView tv2;
    private TextView tv3;
    private Button buttonstart;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
    }

    public void addListenerOnButton()
    {
        sb1 = (SeekBar) findViewById(R.id.sb1);
        sb2 = (SeekBar) findViewById(R.id.sb2);
        sb3 = (SeekBar) findViewById(R.id.sb3);

        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        tv3 = (TextView) findViewById(R.id.tv3);

        buttonstart = (Button) findViewById(R.id.buttonstart);


        buttonstart.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(),Timer_Aktivity.class);
                        intent.putExtra("seekbar1", seekbar1);
                        intent.putExtra("seekbar2", seekbar2);
                        intent.putExtra("seekbar3", seekbar3);
                        startActivity(intent);
                    }
                }
        );

        sb1.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener()
                {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b)
                    {
                        if (i==0)
                        {
                            tv1.setText("10 мин");
                            seekbar1 = 10;

                        } else if (i == 1)
                        {
                            tv1.setText("15 мин");
                            seekbar1 = 15;
                        } else if (i == 2)
                        {
                            tv1.setText("25 мин");
                            seekbar1 = 25;
                        } else if (i==3)
                        {
                            tv1.setText("40 мин");
                            seekbar1 = 40;
                        } else if (i==4)
                        {
                            tv1.setText("50 мин");
                            seekbar1 = 50;
                        } else if (i==5)
                        {
                            tv1.setText("60 мин");
                            seekbar1 = 60;
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar)
                    {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar)
                    {

                    }
                }
        );

        sb2.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                        if (i==0)
                        {
                            tv2.setText("2 мин");
                            seekbar2 = 2;

                        } else if (i == 1)
                        {
                            tv2.setText("3 мин");
                            seekbar2 = 3;
                        } else if (i == 2)
                        {
                            tv2.setText("5 мин");
                            seekbar2 = 5;
                        } else if (i==3)
                        {
                            tv2.setText("7 мин");
                            seekbar2 = 7;
                        } else if (i==4)
                        {
                            tv2.setText("10 мин");
                            seekbar2 = 10;
                        } else if (i==5)
                        {
                            tv2.setText("12 мин");
                            seekbar2 = 12;
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

        sb3.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                        if (i==0)
                        {
                            tv3.setText("5 мин");
                            seekbar3 = 5;

                        } else if (i == 1)
                        {
                            tv3.setText("8 мин");
                            seekbar3 = 8;
                        } else if (i == 2)
                        {
                            tv3.setText("10 мин");
                            seekbar3 = 10;
                        } else if (i==3)
                        {
                            tv3.setText("15 мин");
                            seekbar3 = 15;
                        } else if (i==4)
                        {
                            tv3.setText("20 мин");
                            seekbar3 = 20;
                        } else if (i==5)
                        {
                            tv3.setText("25 мин");
                            seekbar3 = 25;
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );
    }
}