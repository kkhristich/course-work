package com.example.thisispomodoro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class Timer_Aktivity extends AppCompatActivity
{

    TextView tvTime;
    Button btnPause_Start;
    Button btnReset;
    CountDownTimer mainCountDownTimer;

    long minutes;

    final long NUMBER_OF_TIMER = 600000;
    boolean isTimerRunning;
    long timeLeftInMillis;
    long seekbar2;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_aktivity);

        tvTime = findViewById(R.id.tvTime);
        btnPause_Start = findViewById(R.id.btnPause_Start);
        btnReset = findViewById(R.id.btnReset);

        Bundle arguments = getIntent().getExtras();

        minutes = Long.parseLong(arguments.get("seekbar1").toString())*60000;
        seekbar2 = Long.parseLong(arguments.get("seekbar2").toString());

        timeLeftInMillis = minutes;

        btnPause_Start.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (isTimerRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
            }
        });

        updateCountDownText();


    }




    private void startTimer()
    {
        mainCountDownTimer = new CountDownTimer(10000, 1000)
        {
            @Override
            public void onTick(long l)
            {    // l - сколько секунд осталось в таймере

                timeLeftInMillis = l;
                updateCountDownText();
            }

            @Override
            public void onFinish()
            {
                Intent intent2 = new Intent(getApplicationContext(),Activity_short_relax.class);
                intent2.putExtra("seekbar2", seekbar2);
                startActivity(intent2);

            }
        }.start();

        isTimerRunning = true;
        btnPause_Start.setText("Пауза");
        btnReset.setVisibility(View.INVISIBLE);
    }



    private void pauseTimer() {
        mainCountDownTimer.cancel();
        isTimerRunning =false;
        btnPause_Start.setText("Продолжить");
        btnReset.setVisibility(View.VISIBLE);
    }

    private void resetTimer() {

        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
//        timeLeftInMillis = minutes;
//        updateCountDownText();
//        btnReset.setVisibility(View.INVISIBLE);
    }

    private void updateCountDownText() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        String timeLeftTextFormated = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        tvTime.setText(timeLeftTextFormated);

    }


}