package com.example.thisispomodoro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Timer_Aktivity extends AppCompatActivity
{

    TextView tvTime;
    Button btnPause_Start;
    Button btnReset;
    int minutes;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_aktivity);

        tvTime = findViewById(R.id.tvTime);
        btnPause_Start = findViewById(R.id.btnPause_Start);
        btnReset = findViewById(R.id.btnReset);

        Bundle arguments = getIntent().getExtras();

        minutes = Integer.parseInt(arguments.get("seekbar1").toString())*10000;
    }
}